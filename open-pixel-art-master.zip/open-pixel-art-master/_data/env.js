module.exports = {
  isLocal: process.env.PIXEL_ART_RULERS !== 'hide'
};
